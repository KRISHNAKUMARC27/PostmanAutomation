#!/usr/bin/expect

#exp_internal 1

spawn ssh -oStrictHostKeyChecking=no -oCheckHostIP=no root@10.105.90.200

match_max 500000
set expect_out(buffer) {}

set result 0

expect {
  "Password:"
  {
      send "root1234\r";
      expect "#"
      send "su - oracle\r";
      expect "Enter the ORACLE_SID <1: +ASM1>, <2: asmsdb1> :"
      send "2\r";
      expect "$"
      send "sqlplus app1/app1@app1\r";
      expect "SQL>"
      send "select * from ain_product where product_id='TFTURN';\r"
      expect "SQL>"
      foreach line [split $expect_out(buffer) "\n"] {
          if {[regexp -nocase "no rows selected" $line]} {
              set result 1
              break;
          }
      } 
      send "exit\r";
      expect "$"
      send "exit\r";
      expect "#"
      send "exit\r";
      interact
  }

}
exit $result
