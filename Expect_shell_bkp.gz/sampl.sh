#!/usr/bin/expect

set result 0

set ans 1

if { $ans == 1 } {
        var $result = 5
	puts "The value of result is $result"
} else {
        puts "The value of result is $result" 
}

