#!/usr/bin/expect

#exp_internal 1

set osp [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]
set logdir [lindex $argv 4]

set file $lcd/GL_$osp.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set log [open $file w]

set statusfile $lcd/Status_log.[clock format [clock seconds] -format {%Y-%m-%d}]
set status [open $statusfile a]

set httpwired httpwired.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set adminlog admin.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set apptrace apptrace.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set lidbwired lidbwired.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set osplogdir OSP.log.dir.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]

set timeout 5
set prompt ">"

set timestamp [timestamp -format %Y-%m-%d_%H:%M:%S]

spawn ssh -oStrictHostKeyChecking=no -oCheckHostIP=no $user@$osp

match_max 500000
set expect_out(buffer) {}

expect {
  "password:"
  {
        send "$pass\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "mkdir $logdir/logs/$osplogdir\r";
	expect $prompt
        puts $log  $expect_out(buffer)

	send "chmod 777 $logdir/logs/$osplogdir\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "cp -p /iscp/sipdata/restgw/httpwire/httpwired.log $logdir/logs/$osplogdir/$httpwired\r";
	expect $prompt
	puts $log  $expect_out(buffer)

        send "cp -p /iscp/sipdata/restgw/lidb/admin.log $logdir/logs/$osplogdir/$adminlog\r";
	expect $prompt
        puts $log  $expect_out(buffer)

	send "cp -p /iscp/sipdata/restgw/lidb/apptrace.log $logdir/logs/$osplogdir/$apptrace\r";
        expect $prompt
        puts $log  $expect_out(buffer)

        send "cp -p /iscp/sipdata/restgw/lidbwire/lidbwired.log $logdir/logs/$osplogdir/$lidbwired\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "chmod 777 $logdir/logs/$osplogdir/*\r";
	expect $prompt
        puts $log  $expect_out(buffer)

	puts $status "$timestamp : OSP $osp restgw logs collection is SUCCESS"

	send "exit\r";

        interact
  }

  "host: Connection refused"
  {
    send_user "ERROR:EXITING!"
    exit
  }
  
#  "Trying $ngssim..."
#  {
#    send_user "Unable to telnet to $ngssim ERROR:EXITING!"
#    exit
#  }
}

close $log
#expect_eof

