#!/usr/bin/expect

#exp_internal 1

set osp [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]

set file $lcd/HC_$osp.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set log [open $file w]

set statusfile $lcd/Status_log.[clock format [clock seconds] -format {%Y-%m-%d}]
set status [open $statusfile a]

set timeout 5
set prompt ">"

set timestamp [timestamp -format %Y-%m-%d_%H:%M:%S]

spawn ssh -oStrictHostKeyChecking=no -oCheckHostIP=no $user@$osp

match_max 500000
set expect_out(buffer) {}

expect {
  "password:"
  {
        send "$pass\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "getstate '' node all\r";
	expect $prompt
	puts $log  $expect_out(buffer)

        set outcome $expect_out(buffer)
	foreach line [split $outcome "\n"] {
                if {[string match *node_status* $line]} { 
			if { [string match *good* $line]} {
          			puts $status "$timestamp : OSP $osp NODE health is good - SUCCESS"
		        } else {
		        	puts $status "$timestamp : OSP $osp NODE health is not good - ERROR"
			}
			break;
		} 
		if {[regexp "Error processing query for processor" $line]} {
		       puts $status "$timestamp : OSP $osp NODE group is down - ERROR"
		       break;
	        }
	}

        send "getstate '' sip all\r";
        expect $prompt
        puts $log  $expect_out(buffer)

        set outcome $expect_out(buffer)
        foreach line [split $outcome "\n"] {
                if {[string match *sip_status* $line]} {
		       	if { [string match *good* $line]} {
                                puts $status "$timestamp : OSP $osp SIP health is good - SUCCESS"
			} else {
			        puts $status "$timestamp : OSP $osp SIP health is not good - ERROR"
			}
			break;
                } 
		if {[regexp "Error processing query for processor" $line]} {
                       puts $status "$timestamp : OSP $osp SIP group is down - ERROR"
                       break;
                }
        }

	send "exit\r";

        interact
  }

  "host: Connection refused"
  {
    send_user "ERROR:EXITING!"
    exit
  }
  
#  "Trying $ngssim..."
#  {
#    send_user "Unable to telnet to $ngssim ERROR:EXITING!"
#    exit
#  }
}

close $log
#expect_eof

