#!/usr/bin/expect

#exp_internal 1

set logsv [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]
set logdir [lindex $argv 4]

# Do not use log in the tar file name as it can impact tarring of subsequent logs
set tarfile testresults.tar.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]

set timeout 5
set prompt ">"

match_max 500000
set expect_out(buffer) {}

spawn ssh $user@$logsv
expect "password:"
send "$pass\r";
expect $prompt
send "cd $logdir/logs\r";
expect $prompt
send "tar -cvf $tarfile *log*\r";
expect $prompt
send "gzip $tarfile\r";
expect $prompt
send "rm -rf *log*\r";
expect $prompt
send "chmod 777 $tarfile.gz\r";
expect $prompt
send "exit\r";

interact

