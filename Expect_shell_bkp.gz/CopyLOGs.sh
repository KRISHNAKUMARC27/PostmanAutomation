#!/usr/bin/expect

#exp_internal 1

set logsv [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]
set logdir [lindex $argv 4]
set cld [lindex $argv 5]

set timeout 5
set prompt ">"

match_max 500000
set expect_out(buffer) {}

spawn sftp $user@$logsv
expect "password:"
send "$pass\r";
expect $prompt
send "lcd $lcd\r";
expect $prompt
send "cd $logdir/logs\r";
expect $prompt
send "put *log*\r";
expect $prompt
send "lcd $lcd$cld\r";
expect $prompt
send "mkdir $logdir/logs/$cld\r";
expect $prompt
send "cd $logdir/logs/$cld\r";
expect $prompt
send "put *log*\r";
expect $prompt
send "exit\r";

interact

