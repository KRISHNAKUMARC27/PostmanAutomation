#!/usr/bin/expect

#exp_internal 1

set cp [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]
set logdir [lindex $argv 4]
set action [lindex $argv 5]

set file $lcd/IP_$cp.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set log [open $file w]

set statusfile $lcd/Status_log.[clock format [clock seconds] -format {%Y-%m-%d}]
set status [open $statusfile a]

set timeout 5
set prompt ">"

set timestamp [timestamp -format %Y-%m-%d_%H:%M:%S]

spawn ssh -oStrictHostKeyChecking=no -oCheckHostIP=no $user@$cp

match_max 500000
set expect_out(buffer) {}

expect {
  "password:"
  {
        send "$pass\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	if {[regexp -nocase "START" $action]} {
        	send "startsrc -s iptrace -a $logdir/logs/$cp.logtraceout.$timestamp\r";
	        expect $prompt
        	puts $log  $expect_out(buffer)
                puts $status "$timestamp : $cp IPTracelogs collection START is SUCCESS"
	} else {
                send "stopsrc -s iptrace\r";
                expect $prompt
                puts $log  $expect_out(buffer)
                puts $status "$timestamp : $cp IPTracelogs collection STOP is SUCCESS"
        } 
	send "exit\r";

        interact
  }

  "host: Connection refused"
  {
    send_user "ERROR:EXITING!"
    exit
  }
  
#  "Trying $ngssim..."
#  {
#    send_user "Unable to telnet to $ngssim ERROR:EXITING!"
#    exit
#  }
}

close $log
#expect_eof

