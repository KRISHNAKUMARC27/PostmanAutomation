#!/usr/bin/expect

set ngssim [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]
set logdir [lindex $argv 4]
set stsim [lindex $argv 5]

set file $lcd/TC_start_$stsim.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set log [open $file w]

set statusfile $lcd/Status_log.[clock format [clock seconds] -format {%Y-%m-%d}]
set status [open $statusfile a]

set timestamp [timestamp -format %Y-%m-%d_%H:%M:%S]

set f [open "$lcd/STsim_commands.txt"]
set commands [split [read $f] "\n"]

set timeout 60
set prompt "/user/ngsadm>"
set ompprompt "CMD>"
set testcompleteprompt "TEST IS COMPLETE"

set ttylogfile $logdir/logs/$stsim.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]

spawn telnet $ngssim

match_max 500000
set expect_out(buffer) {}

expect {
  "login:"
  {
        send "$user\r"
	expect "Password:"
        send "$pass\r";
	puts $log  $expect_out(buffer)
        expect $prompt
        puts $log  $expect_out(buffer)

	send "omp $stsim\r";
        expect $ompprompt
        puts $log  $expect_out(buffer)

        send "start ttylog $ttylogfile\r";
	expect $ompprompt
	puts $log  $expect_out(buffer)

	foreach cmd $commands {
		send "\r";
		expect $ompprompt
		send "$cmd\r";
		puts $log  $expect_out(buffer)
	}
        send "\r";

	expect $testcompleteprompt
        puts $log  $expect_out(buffer)	

	set lines [split $expect_out(buffer) \n]
        set xmited [lindex $lines 8]
	set rcvd [lindex $lines 9]
        puts $log "CHGD"
        puts $log $xmited
	puts $log $rcvd

        foreach line [split $expect_out(buffer) "\n"] {
		if {[regexp -nocase "Msgs Xmitted" $line]} {
			puts $log "HGD2"
			puts $log $line
		}
	}

	send "exit\r";
	expect $prompt
        puts $log  $expect_out(buffer)

	send "chmod 777 $ttylogfile\r"

	send "exit\r";
        puts $status "$timestamp : The ST simulator test completed SUCCESS"  
        interact
  }

  "host: Connection refused"
  {
    send_user "ERROR:EXITING!"
    exit
  }
  
#  "Trying $ngssim..."
#  {
#    send_user "Unable to telnet to $ngssim ERROR:EXITING!"
#    exit
#  }
}
close $log
#expect_eof

