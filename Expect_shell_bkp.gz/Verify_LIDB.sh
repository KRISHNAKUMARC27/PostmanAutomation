#!/usr/bin/expect

#exp_internal 1

set cp [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]
set record [lindex $argv 4]
set value [lindex $argv 5]

set file $lcd/VerifyLidb_$cp.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set log [open $file w]

set statusfile $lcd/Status_log.[clock format [clock seconds] -format {%Y-%m-%d}]
set status [open $statusfile a]

set timeout 5
set prompt ">"

set timestamp [timestamp -format %Y-%m-%d_%H:%M:%S]

spawn ssh -oStrictHostKeyChecking=no -oCheckHostIP=no $user@$cp

match_max 500000
set expect_out(buffer) {}

set result 0

expect {
  "password:"
  {
        send "$pass\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "editdb 01 -offline\r";
	expect $prompt
	puts $log  $expect_out(buffer)

	if {[regexp -nocase "LRN" $record]} {
		send "RL\r";
		expect "# =";
		puts $log  $expect_out(buffer)

		send "$value\r";
	       	expect $prompt
		puts $log  $expect_out(buffer)

		set lines [split $expect_out(buffer) \n]
		set c [lindex $lines 3]

		foreach line [split $expect_out(buffer) "\n"] {
			if {[regexp -nocase "INVALID ENTRY" $line]} {
                                puts  $status "$timestamp : $cp : LRN : $value INVALID ENTRY - ERROR"
				set result 1
                                break;
                        } elseif {[regexp -nocase "RL" $line]} {
				if {[regexp -nocase "NOT IN LIDB" $c]} {
                                        puts $status "$timestamp : $cp : LRN : $value not found in LIDB - ERROR"
					set result 1
                                } elseif {[regexp -nocase "NOT ALLOWED" $c]} {
                                        puts $status "$timestamp : $cp : LRN : $value Security Violation in LIDB - ERROR"
					set result 1
			        } else {
				        puts $status "$timestamp : $cp : LRN : $value found in LIDB - SUCCESS"
					set result 0
				}
                                break;
		        }
		}
	} else {
	        send "RG\r";
                expect "# =";
                puts $log  $expect_out(buffer)

                send "$value\r";
                expect $prompt
                puts $log  $expect_out(buffer)

		set lines [split $expect_out(buffer) \n]
                set c [lindex $lines 3]

                foreach line [split $expect_out(buffer) "\n"] {
                        if {[regexp -nocase "INVALID ENTRY" $line]} {
                                puts  $status "$timestamp : $cp : GRN : $value INVALID ENTRY - ERROR"
				set result 1
                                break;
                        } elseif {[regexp -nocase "RG" $line]} {
                                if {[regexp -nocase "NOT IN LIDB" $c]} {
                                        puts $status "$timestamp : $cp : GRN : $value not found in LIDB - ERROR"
					set result 1
                                } elseif {[regexp -nocase "NOT ALLOWED" $c]} {
                                        puts $status "$timestamp : $cp : GRN : $value Security Violation in LIDB - ERROR"
					set result 1
                                } else {
                                        puts $status "$timestamp : $cp : GRN : $value found in LIDB - SUCCESS"
					set result 0
                                }
                                break;
                        }
                }
	}

        send "\03";
        expect $prompt
        puts $log  $expect_out(buffer)
        send "LO\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "exit\r";
        interact
  }

  "host: Connection refused"
  {
    send_user "ERROR:EXITING!"
    exit
  }
  
#  "Trying $ngssim..."
#  {
#    send_user "Unable to telnet to $ngssim ERROR:EXITING!"
#    exit
#  }
}

close $log
#expect_eof
exit $result
