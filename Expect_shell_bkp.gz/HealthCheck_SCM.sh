#!/usr/bin/expect

#exp_internal 1

set scm [lindex $argv 0]
set user [lindex $argv 1]
set pass [lindex $argv 2]
set lcd [lindex $argv 3]

set file $lcd/HC_$scm.log.[clock format [clock seconds] -format {%Y-%m-%d}]_[clock format [clock seconds] -format %H-%M-%S]
set log [open $file w]

set statusfile $lcd/Status_log.[clock format [clock seconds] -format {%Y-%m-%d}]
set status [open $statusfile a]

set timeout 5
set prompt ">"

set timestamp [timestamp -format %Y-%m-%d_%H:%M:%S]

spawn ssh -oStrictHostKeyChecking=no -oCheckHostIP=no $user@$scm

match_max 500000
set expect_out(buffer) {}

expect {
  "password:"
  {
        send "$pass\r";
        expect $prompt
        puts $log  $expect_out(buffer)

	send "getstate '' ss7 all\r";
	expect $prompt
	puts $log  $expect_out(buffer)

        set outcome $expect_out(buffer)
	foreach line [split $outcome "\n"] {
                if {[string match *ss7_status* $line] } {
			if {[string match *good* $line]} {
			        puts $status "$timestamp : SCM $scm SS7 health is good - SUCCESS"
			} else {
			        puts $status "$timestamp : SCM $scm SS7 health is bad - ERROR"
			}
			break;
		}
                if {[regexp "Error processing query for processor" $line]} {
                       puts $status "$timestamp : SCM $scm SS7 group is down - ERROR"
                       break;
                }
	}

	send "exit\r";

        interact
  }

  "host: Connection refused"
  {
    send_user "ERROR:EXITING!"
    exit
  }
  
#  "Trying $ngssim..."
#  {
#    send_user "Unable to telnet to $ngssim ERROR:EXITING!"
#    exit
#  }
}

close $log
#expect_eof

